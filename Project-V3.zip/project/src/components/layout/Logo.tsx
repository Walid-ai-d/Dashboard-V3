import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="bg-black text-white px-3 py-1 rounded-lg font-bold text-lg">
      alt
    </div>
  );
};

export default Logo;